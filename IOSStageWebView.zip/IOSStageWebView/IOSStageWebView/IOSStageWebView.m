#import "IOSStageWebView.h"

#import "FlashRuntimeExtensions.h"
@implementation UIViewExtension

UIWebView *webView;
FREContext *context;


- (id)init
{
    self = [super init];
    if (self) {
        
        
        
        // Initialization code here.
    }
    
    return self;
}


//invoke javascript function
//get the response from javascript
//parse the response to flex
FREObject invokeJS(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[] )
{
    
    //call your javasript here and get the respone
    
    
    //or you can just do some logic stuff here
    
    
    
    
    context = ctx;
     //change this response string in your own implementation
    NSString *returnValue = @"success!!!!!";
   
    
    NSString *eventName = @"RESPONSE_RETURN";
    
    //this is the way you dispatch your event to 
    FREDispatchStatusEventAsync(context, (uint8_t*)[eventName UTF8String], (uint8_t*)[returnValue UTF8String]);
    
    context = nil;
    
    
    return NULL;
}


FREObject loadURL(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[] )
{
    
    uint32_t urlLength;
    uint32_t first;
    uint32_t second;
    uint32_t third;
    uint32_t forth;
    
    const uint8_t *urlAS;
    const uint8_t *x;
    const uint8_t *y;
    const uint8_t *width;
    const uint8_t *height;
    
    
    FREGetObjectAsUTF8(argv[0], &urlLength,&urlAS);
    FREGetObjectAsUTF8(argv[1], &first, &x);
    FREGetObjectAsUTF8(argv[2], &second,&y);
    FREGetObjectAsUTF8(argv[3], &third,&width);
    FREGetObjectAsUTF8(argv[4], &forth, &height);    
    
    NSString *inputPath = [NSString stringWithUTF8String:(char*)urlAS];
    NSString *xString = [NSString stringWithUTF8String:(char*)x];
    NSString *yString = [NSString stringWithUTF8String:(char*)y];
    NSString *widthString = [NSString stringWithUTF8String:(char*)width];
    NSString *heightString = [NSString stringWithUTF8String:(char*)height];
    
    
    int oX = [xString intValue];
    int oY = [yString intValue];
    int oWidth = [widthString intValue];
    int oHeight = [heightString intValue];
    
    
    
    
    
    
    
    
    UIWindow *keyWindow= [[UIApplication sharedApplication]keyWindow];
    UIViewController *mainController = [keyWindow rootViewController];
    
    
    webView =[[UIWebView alloc]initWithFrame:CGRectMake(oX, oY, oWidth, oHeight)];
    
    
    
    
    NSString *urlAddress = inputPath;
    
  
    NSURL *url = [NSURL URLWithString:urlAddress];
 
    NSURLRequest *requestObj = [NSURLRequest requestWithURL:url];
    

    [webView loadRequest:requestObj];
 
    [mainController.view addSubview:webView];
    
    
    return NULL;    
}



-(void)buttonPressed {
    NSLog(@"Button Pressed!");
    
    [webView removeFromSuperview];
}
//------------------------------------
//
// Required Methods.
//
//------------------------------------

// ContextInitializer()
//
// The context initializer is called when the runtime creates the extension context instance.
void ContextInitializerA(void* extData, const uint8_t* ctxType, FREContext ctx, 
                         uint32_t* numFunctionsToTest, const FRENamedFunction** functionsToSet) 
{
    
	*numFunctionsToTest = 2;
    
	FRENamedFunction* func = (FRENamedFunction*) malloc(sizeof(FRENamedFunction) * 2);
	func[0].name = (const uint8_t*) "loadURL";
	func[0].functionData = NULL;
    func[0].function = &loadURL;
    
    func[1].name =(const uint8_t*) "invokeJS";
    func[1].functionData = NULL;
    func[1].function = &invokeJS;
    
    
    
	*functionsToSet = func;
}

// ContextFinalizer()
//
// The context finalizer is called when the extension's ActionScript code
// calls the ExtensionContext instance's dispose() method.
// If the AIR runtime garbage collector disposes of the ExtensionContext instance, the runtime also calls
// ContextFinalizer().

void ContextFinalizerA(FREContext ctx) {
    
    NSLog(@"Entering ContextFinalizer()");
    
    [webView removeFromSuperview];
    
    
    NSLog(@"Exiting ContextFinalizer()");
    
	return;
}

// ExtInitializer()
//
// The extension initializer is called the first time the ActionScript side of the extension
// calls ExtensionContext.createExtensionContext() for any context.

void ExtInitializerA(void** extDataToSet, FREContextInitializer* ctxInitializerToSet, 
                     FREContextFinalizer* ctxFinalizerToSet) {
    
    NSLog(@"Entering ExtInitializer()");
    
    *extDataToSet = NULL;
    *ctxInitializerToSet = &ContextInitializerA;
    *ctxFinalizerToSet = &ContextFinalizerA;
    
    NSLog(@"Exiting ExtInitializer()");
}

// ExtFinalizer()
//
// The extension finalizer is called when the runtime unloads the extension. However, it is not always called.

void ExtFinalizerA(void* extData) {
    
    NSLog(@"Entering ExtFinalizer()");
    
    // Nothing to clean up.
    
    NSLog(@"Exiting ExtFinalizer()");
    return;
}



@end

